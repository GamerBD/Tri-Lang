// Helper: shuffle array items randomly
function shuffleArray(arr) {
  return arr.sort(() => Math.random() - 0.5);
}

// Word banks for realistic wrong options
const wordBanks = {
  spanish: ["Adiós", "Gracias", "Perro", "Casa", "Libro", "Amigo", "Pan", "Agua", "Queso"],
  french: ["Merci", "Chat", "Chien", "Voisin", "Ennemi", "Pain", "Eau", "Fromage", "Salut"],
  russian: ["Спасибо", "Дом", "Кошка", "Друг", "Вода", "Хлеб", "Книга", "Привет", "Пока"],
  hindi: ["धन्यवाद", "कुत्ता", "घर", "दोस्त", "पानी", "रोटी", "किताब", "नमस्ते", "अलविदा"],
  chinese: ["谢谢", "狗", "家", "朋友", "水", "面包", "书", "你好", "再见"],
  bangla: ["ধন্যবাদ", "কুকুর", "বাড়ি", "বন্ধু", "পানি", "রুটি", "বই", "হ্যালো", "বিদায়"],
  german: ["Danke", "Hund", "Haus", "Freund", "Wasser", "Brot", "Buch", "Hallo", "Auf Wiedersehen"],
};

// Get a list of 3 realistic wrong options for a language and correct word
function getWrongOptions(language, correct) {
  const bank = wordBanks[language] || [];
  const filtered = bank.filter(w => w.toLowerCase() !== correct.toLowerCase());
  const shuffled = shuffleArray(filtered);
  return shuffled.slice(0, 3);
}

// Get correct words for greetings
function getHelloWord(lang) {
  const dict = {
    spanish: "Hola",
    french: "Bonjour",
    russian: "Здравствуйте",
    hindi: "नमस्ते",
    chinese: "你好",
    bangla: "হ্যালো",
    german: "Hallo",
  };
  return dict[lang] || "Hello";
}

function getThankYouWord(lang) {
  const dict = {
    spanish: "Gracias",
    french: "Merci",
    russian: "Спасибо",
    hindi: "धन्यवाद",
    chinese: "谢谢",
    bangla: "ধন্যবাদ",
    german: "Danke",
  };
  return dict[lang] || "Thank you";
}

function getGoodbyeWord(lang) {
  const dict = {
    spanish: "Adiós",
    french: "Au revoir",
    russian: "До свидания",
    hindi: "अलविदा",
    chinese: "再见",
    bangla: "বিদায়",
    german: "Auf Wiedersehen",
  };
  return dict[lang] || "Goodbye";
}

// Generate a lesson with 3 questions
function generateLesson(language, lessonNumber) {
  const hello = getHelloWord(language);
  const thankYou = getThankYouWord(language);
  const goodbye = getGoodbyeWord(language);

  return {
    id: `lesson${lessonNumber}`,
    name: `Lesson ${lessonNumber}`,
    unlocked: true,
    questions: [
      {
        type: "multiple",
        word: `Hello in ${language} (lesson ${lessonNumber})`,
        correct: hello,
        options: shuffleArray([hello, ...getWrongOptions(language, hello)]),
      },
      {
        type: "multiple",
        word: `Thank you in ${language} (lesson ${lessonNumber})`,
        correct: thankYou,
        options: shuffleArray([thankYou, ...getWrongOptions(language, thankYou)]),
      },
      {
        type: "multiple",
        word: `Goodbye in ${language} (lesson ${lessonNumber})`,
        correct: goodbye,
        options: shuffleArray([goodbye, ...getWrongOptions(language, goodbye)]),
      },
    ],
  };
}

// Current state
let currentLanguage = null;
let currentLessonNumber = 1;
let currentQuestionIndex = 0;
let xp = parseInt(localStorage.getItem("xp") || "0");
let streak = parseInt(localStorage.getItem("streak") || "0");

let lessonTimer = null;
const lessonDuration = 180; // 3 minutes in seconds
let timeLeft = lessonDuration;

let hearts = 3;
const maxHearts = 3;

// DOM Elements
const xpEl = document.getElementById("xp");
const streakEl = document.getElementById("streak");
const languageSelectEl = document.getElementById("language-select");
const skillTreeEl = document.getElementById("skill-tree");
const lessonsContainer = document.getElementById("lessons-container");
const lessonArea = document.getElementById("lesson-area");
const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const textAnswerEl = document.getElementById("text-answer");
const submitBtn = document.getElementById("submit-btn");
const feedbackEl = document.getElementById("feedback");
const heartsEl = document.getElementById("hearts");
const timerEl = document.getElementById("timer");

updateStats();

function startLanguage(lang) {
  currentLanguage = lang;
  languageSelectEl.style.display = "none";
  showSkillTree();
}

function showSkillTree() {
  skillTreeEl.style.display = "block";
  lessonArea.style.display = "none";
  lessonsContainer.innerHTML = "";

  // Show initial 5 lessons
  for (let i = 1; i <= 5; i++) {
    const btn = document.createElement("button");
    btn.textContent = `Lesson ${i}`;
    btn.disabled = false;
    btn.onclick = () => startLesson(i);
    lessonsContainer.appendChild(btn);
  }

  // Load More button
  const loadMoreBtn = document.createElement("button");
  loadMoreBtn.textContent = "Load More Lessons";
  loadMoreBtn.onclick = () => {
    const currentCount = lessonsContainer.querySelectorAll("button").length - 1; // exclude Load More
    for (let i = currentCount + 1; i <= currentCount + 5; i++) {
      const btn = document.createElement("button");
      btn.textContent = `Lesson ${i}`;
      btn.disabled = false;
      btn.onclick = () => startLesson(i);
      lessonsContainer.insertBefore(btn, loadMoreBtn);
    }
  };
  lessonsContainer.appendChild(loadMoreBtn);
}

function startLesson(lessonNumber) {
  currentLessonNumber = lessonNumber;
  currentQuestionIndex = 0;
  timeLeft = lessonDuration;
  hearts = maxHearts;
  updateHeartsDisplay();
  skillTreeEl.style.display = "none";
  lessonArea.style.display = "block";
  startLessonTimer();
  showQuestion();
}

function startLessonTimer() {
  clearInterval(lessonTimer);
  updateTimerDisplay();
  lessonTimer = setInterval(() => {
    timeLeft--;
    updateTimerDisplay();
    if (timeLeft <= 0) {
      clearInterval(lessonTimer);
      alert("⏰ Time's up! Lesson ended.");
      finishLesson();
    }
  }, 1000);
}

function updateTimerDisplay() {
  timerEl.textContent = `Time left: ${timeLeft}s`;
}

function updateHeartsDisplay() {
  heartsEl.textContent = `❤️ Hearts: ${"❤️".repeat(hearts)}${"🤍".repeat(maxHearts - hearts)}`;
}

function showQuestion() {
  const lesson = generateLesson(currentLanguage, currentLessonNumber);
  const q = lesson.questions[currentQuestionIndex];

  questionEl.textContent = `Translate: ${q.word}`;
  feedbackEl.textContent = "";
  optionsEl.innerHTML = "";
  textAnswerEl.classList.add("hidden");
  submitBtn.classList.add("hidden");
  textAnswerEl.value = "";

  speak(q.word);

  // "I don't know" button
  const dontKnowBtn = document.createElement("button");
  dontKnowBtn.textContent = "I don't know ❓";
  dontKnowBtn.onclick = () => showCorrectAnswer(q.correct);
  optionsEl.appendChild(dontKnowBtn);

  if (q.type === "multiple") {
    q.options.forEach(opt => {
      const btn = document.createElement("button");
      btn.textContent = opt;
      btn.onclick = () => checkAnswer(opt);
      optionsEl.appendChild(btn);
    });
  } else {
    textAnswerEl.classList.remove("hidden");
    submitBtn.classList.remove("hidden");
    submitBtn.onclick = () => checkAnswer(textAnswerEl.value.trim());
  }
}

function checkAnswer(ans) {
  const lesson = generateLesson(currentLanguage, currentLessonNumber);
  const q = lesson.questions[currentQuestionIndex];

  if (ans.toLowerCase() === q.correct.toLowerCase()) {
    feedbackEl.textContent = "✅ Correct!";
    xp += 10;
    streak += 1;
    updateStats();

    currentQuestionIndex++;
    if (currentQuestionIndex >= lesson.questions.length) {
      finishLesson();
    } else {
      showQuestion();
    }
  } else {
    hearts--;
    updateHeartsDisplay();
    feedbackEl.textContent = `❌ Incorrect! Hearts left: ${hearts}`;
    streak = 0;
    updateStats();
    if (hearts <= 0) {
      alert("💔 No hearts left! Lesson over.");
      finishLesson();
    }
  }
}

function showCorrectAnswer(correct) {
  hearts--;
  updateHeartsDisplay();
  feedbackEl.textContent = `💡 The correct answer is: "${correct}". Hearts left: ${hearts}`;
  streak = 0;
  updateStats();
  if (hearts <= 0) {
    setTimeout(() => {
      alert("💔 No hearts left! Lesson over.");
      finishLesson();
    }, 1500);
  } else {
    setTimeout(() => {
      currentQuestionIndex++;
      const lesson = generateLesson(currentLanguage, currentLessonNumber);
      if (currentQuestionIndex >= lesson.questions.length) {
        finishLesson();
      } else {
        showQuestion();
      }
    }, 2000);
  }
}

function finishLesson() {
  clearInterval(lessonTimer);
  showSkillTree();
  alert(`🎉 You finished lesson ${currentLessonNumber} in ${currentLanguage}!`);
}

function backToSkillTree() {
  clearInterval(lessonTimer);
  lessonArea.style.display = "none";
  skillTreeEl.style.display = "block";
}

function goBackToLanguages() {
  clearInterval(lessonTimer);
  lessonTimer = null;
  timeLeft = lessonDuration;
  hearts = maxHearts;
  currentLanguage = null;
  currentLessonNumber = 1;
  currentQuestionIndex = 0;
  feedbackEl.textContent = "";
  textAnswerEl.value = "";
  optionsEl.innerHTML = "";
  lessonArea.style.display = "none";
  skillTreeEl.style.display = "none";
  languageSelectEl.style.display = "block";
}

function updateStats() {
  xpEl.textContent = xp;
  streakEl.textContent = streak;
  localStorage.setItem("xp", xp);
  localStorage.setItem("streak", streak);
}

function speak(text) {
  if ("speechSynthesis" in window) {
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = "en-US";
    speechSynthesis.speak(utter);
  }
}

// Setup language buttons and navigation on DOM ready
document.addEventListener("DOMContentLoaded", () => {
  // Language buttons must have data-lang attribute
  document.querySelectorAll('#language-select button').forEach(btn => {
    btn.addEventListener('click', () => {
      const lang = btn.getAttribute("data-lang");
      if (lang) startLanguage(lang);
    });
  });

  document.getElementById('back-to-languages-1').addEventListener('click', goBackToLanguages);
  document.getElementById('back-to-languages-2').addEventListener('click', goBackToLanguages);
  document.getElementById('back-to-skill-tree').addEventListener('click', backToSkillTree);
});
