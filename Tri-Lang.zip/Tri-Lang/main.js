// Helper: shuffle array items randomly
function shuffleArray(arr) {
  return arr.sort(() => Math.random() - 0.5);
}

// Word banks for realistic wrong options, now including phonetic pronunciations
// These words are used for the *incorrect* options in multiple-choice questions.
const wordBanks = {
  spanish: [
    { word: "Adiós", phonetic: "ah-dee-OHS" },
    { word: "Gracias", phonetic: "GRAH-syahs" },
    { word: "Perro", phonetic: "PEH-rroh" },
    { word: "Casa", phonetic: "KAH-sah" },
    { word: "Libro", phonetic: "LEE-broh" },
    { word: "Amigo", phonetic: "ah-MEE-goh" },
    { word: "Pan", phonetic: "pahn" },
    { word: "Agua", phonetic: "AH-gwah" },
    { word: "Queso", phonetic: "KEH-soh" }
  ],
  french: [
    { word: "Merci", phonetic: "mer-SEE" },
    { word: "Chat", phonetic: "shah" },
    { word: "Chien", phonetic: "shyen" },
    { word: "Voisin", phonetic: "vwah-ZAN" },
    { word: "Ennemi", phonetic: "en-mee" },
    { word: "Pain", phonetic: "pan" },
    { word: "Eau", phonetic: "oh" },
    { word: "Fromage", phonetic: "froh-MAHZH" },
    { word: "Salut", phonetic: "sah-LOO" }
  ],
  russian: [
    { word: "Спасибо", phonetic: "spuh-SEE-buh" },
    { word: "Дом", phonetic: "dom" },
    { word: "Кошка", phonetic: "KOSH-kuh" },
    { word: "Друг", phonetic: "droog" },
    { word: "Вода", phonetic: "vah-DAH" },
    { word: "Хлеб", phonetic: "khlyep" },
    { word: "Книга", phonetic: "KNEE-gah" },
    { word: "Привет", phonetic: "pree-VYET" },
    { word: "Пока", phonetic: "pah-KAH" }
  ],
  hindi: [
    { word: "धन्यवाद", phonetic: "dhun-yuh-VAHD" },
    { word: "कुत्ता", phonetic: "KOOT-tah" },
    { word: "घर", phonetic: "ghar" },
    { word: "दोस्त", phonetic: "dost" },
    { word: "पानी", phonetic: "PAH-nee" },
    { word: "रोटी", phonetic: "ROH-tee" },
    { word: "किताब", phonetic: "kee-TAHB" },
    { word: "नमस्ते", phonetic: "nah-MAH-stay" },
    { word: "अलविदा", phonetic: "al-vee-DAH" }
  ],
  chinese: [
    { word: "谢谢", phonetic: "shyeh-shyeh" },
    { word: "狗", phonetic: "goh" },
    { word: "家", phonetic: "jee-ah" },
    { word: "朋友", phonetic: "pung-yoh" },
    { word: "水", phonetic: "shway" },
    { word: "面包", phonetic: "myen-baow" },
    { word: "书", phonetic: "shoo" },
    { word: "你好", phonetic: "nee-HAOW" },
    { word: "再见", phonetic: "zai-JYEN" }
  ],
  bangla: [
    { word: "ধন্যবাদ", phonetic: "dhon-no-BAHD" },
    { word: "কুকুর", phonetic: "koo-KOOR" },
    { word: "বাড়ি", phonetic: "bah-ree" },
    { word: "বন্ধু", phonetic: "bon-dhoo" },
    { word: "পানি", phonetic: "pah-nee" },
    { word: "রুটি", phonetic: "roo-tee" },
    { word: "বই", phonetic: "boy" },
    { word: "হ্যালো", phonetic: "HEH-loh" },
    { word: "বিদায়", phonetic: "bee-DAI" }
  ],
  german: [
    { word: "Danke", phonetic: "DAHN-kuh" },
    { word: "Hund", phonetic: "hoont" },
    { word: "Haus", phonetic: "hows" },
    { word: "Freund", phonetic: "froynt" },
    { word: "Wasser", phonetic: "VAH-ser" },
    { word: "Brot", phonetic: "broht" },
    { word: "Buch", phonetic: "booh" },
    { word: "Hallo", phonetic: "HAH-loh" },
    { word: "Auf Wiedersehen", phonetic: "owf VEE-der-zay-en" }
  ],
};

// Main data structure for core words, including both English and foreign word pronunciations
const languageWords = {
  spanish: {
    hello: { english: "Hello", englishPhonetic: "HEH-loh", word: "Hola", phonetic: "OH-lah" },
    thankYou: { english: "Thank you", englishPhonetic: "THANK yoo", word: "Gracias", phonetic: "GRAH-syahs" },
    goodbye: { english: "Goodbye", englishPhonetic: "good-BYE", word: "Adiós", phonetic: "ah-dee-OHS" },
  },
  french: {
    hello: { english: "Hello", englishPhonetic: "HEH-loh", word: "Bonjour", phonetic: "bon-ZHOOR" },
    thankYou: { english: "Thank you", englishPhonetic: "THANK yoo", word: "Merci", phonetic: "mer-SEE" },
    goodbye: { english: "Goodbye", englishPhonetic: "good-BYE", word: "Au revoir", phonetic: "oh ruh-VWAHR" },
  },
  russian: {
    hello: { english: "Hello", englishPhonetic: "HEH-loh", word: "Здравствуйте", phonetic: "ZDRAHV-stvooy-tyeh" },
    thankYou: { english: "Thank you", englishPhonetic: "THANK yoo", word: "Спасибо", phonetic: "spuh-SEE-buh" },
    goodbye: { english: "Goodbye", englishPhonetic: "good-BYE", word: "До свидания", phonetic: "duh svee-DAH-nee-yuh" },
  },
  hindi: {
    hello: { english: "Hello", englishPhonetic: "HEH-loh", word: "नमस्ते", phonetic: "nah-MAH-stay" },
    thankYou: { english: "Thank you", englishPhonetic: "THANK yoo", word: "धन्यवाद", phonetic: "dhun-yuh-VAHD" },
    goodbye: { english: "Goodbye", englishPhonetic: "good-BYE", word: "अलविदा", phonetic: "al-vee-DAH" },
  },
  chinese: {
    hello: { english: "Hello", englishPhonetic: "HEH-loh", word: "你好", phonetic: "nee-HAOW" },
    thankYou: { english: "Thank you", englishPhonetic: "THANK yoo", word: "谢谢", phonetic: "shyeh-shyeh" },
    goodbye: { english: "Goodbye", englishPhonetic: "good-BYE", word: "再见", phonetic: "zai-JYEN" },
  },
  bangla: {
    hello: { english: "Hello", englishPhonetic: "HEH-loh", word: "হ্যালো", phonetic: "HEH-loh" },
    thankYou: { english: "Thank you", englishPhonetic: "THANK yoo", word: "ধন্যবাদ", phonetic: "dhon-no-BAHD" },
    goodbye: { english: "Goodbye", englishPhonetic: "good-BYE", word: "বিদায়", phonetic: "bee-DAI" },
  },
  german: {
    hello: { english: "Hello", englishPhonetic: "HEH-loh", word: "Hallo", phonetic: "HAH-loh" },
    thankYou: { english: "Thank you", englishPhonetic: "THANK yoo", word: "Danke", phonetic: "DAHN-kuh" },
    goodbye: { english: "Goodbye", englishPhonetic: "good-BYE", word: "Auf Wiedersehen", phonetic: "owf VEE-der-zay-en" },
  },
};

// Get a list of 3 realistic wrong options for a language and correct word
function getWrongOptions(language, correctWord) {
  const bank = wordBanks[language] || [];
  // Filter by the 'word' property
  const filtered = bank.filter(item => item.word.toLowerCase() !== correctWord.toLowerCase());
  const shuffled = shuffleArray(filtered);
  // Return only the 'word' strings for the options, as the phonetic will be looked up later
  return shuffled.slice(0, 3).map(item => item.word);
}

// Generate a lesson with 3 questions
function generateLesson(language, lessonNumber) {
  const langData = languageWords[language];

  // If language data is missing, provide default English words
  const helloData = langData ? langData.hello : { english: "Hello", englishPhonetic: "HEH-loh", word: "Hello", phonetic: "HEH-loh" };
  const thankYouData = langData ? langData.thankYou : { english: "Thank you", englishPhonetic: "THANK yoo", word: "Thank you", phonetic: "THANK yoo" };
  const goodbyeData = langData ? langData.goodbye : { english: "Goodbye", englishPhonetic: "good-BYE", word: "Goodbye", phonetic: "good-BYE" };

  return {
    id: `lesson${lessonNumber}`,
    name: `Lesson ${lessonNumber}`,
    unlocked: true,
    questions: [
      {
        type: "multiple",
        promptEnglish: helloData.english, // "Hello"
        promptEnglishPhonetic: helloData.englishPhonetic, // "HEH-loh"
        correctAnswer: helloData.word, // "Hola"
        correctAnswerPhonetic: helloData.phonetic, // "OH-lah"
        options: shuffleArray([helloData.word, ...getWrongOptions(language, helloData.word)]),
      },
      {
        type: "multiple",
        promptEnglish: thankYouData.english, // "Thank you"
        promptEnglishPhonetic: thankYouData.englishPhonetic, // "THANK yoo"
        correctAnswer: thankYouData.word, // "Gracias"
        correctAnswerPhonetic: thankYouData.phonetic, // "GRAH-syahs"
        options: shuffleArray([thankYouData.word, ...getWrongOptions(language, thankYouData.word)]),
      },
      {
        type: "multiple",
        promptEnglish: goodbyeData.english, // "Goodbye"
        promptEnglishPhonetic: goodbyeData.englishPhonetic, // "good-BYE"
        correctAnswer: goodbyeData.word, // "Adiós"
        correctAnswerPhonetic: goodbyeData.phonetic, // "ah-dee-OHS"
        options: shuffleArray([goodbyeData.word, ...getWrongOptions(language, goodbyeData.word)]),
      },
    ],
  };
}

// Current state
let currentLanguage = null;
let currentLessonNumber = 1;
let currentQuestionIndex = 0;
let xp = parseInt(localStorage.getItem("xp") || "0");
let streak = parseInt(localStorage.getItem("streak") || "0");

let lessonTimer = null;
const lessonDuration = 180; // 3 minutes in seconds
let timeLeft = lessonDuration;

let hearts = 3;
const maxHearts = 3;

// DOM Elements
const xpEl = document.getElementById("xp");
const streakEl = document.getElementById("streak");
const languageSelectEl = document.getElementById("language-select");
const skillTreeEl = document.getElementById("skill-tree");
const lessonsContainer = document.getElementById("lessons-container");
const lessonArea = document.getElementById("lesson-area");
const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const textAnswerEl = document.getElementById("text-answer");
const submitBtn = document.getElementById("submit-btn");
const feedbackEl = document.getElementById("feedback");
const heartsEl = document.getElementById("hearts");
const timerEl = document.getElementById("timer");
const welcomeScreenEl = document.getElementById("welcome-screen");
const startLearningBtn = document.getElementById("start-learning-btn");
const mascotEl = document.getElementById("mascot"); // Get mascot element

// Mascot movement variables
let mascotPosition = 0; // Current horizontal position
let mascotDirection = 1; // 1 for right, -1 for left
const mascotSpeed = 0.5; // Pixels per frame
let mascotAnimationId; // To control requestAnimationFrame

// TriBlaze's encouraging messages
const triblazeMessages = [
  "You're doing great, Gamer BD!",
  "Keep up the awesome work!",
  "Learning new languages is super cool!",
  "Tri-Lang is here to help you shine!",
  "Every word counts, keep going!",
  "You've got this!",
  "Level up your language skills!",
  "Stay sharp, stay focused!",
  "TriBlaze believes in you!",
  "Another word, another victory!"
];

updateStats();

function startLanguage(lang) {
  currentLanguage = lang;
  languageSelectEl.style.display = "none";
  showSkillTree();
}

function showSkillTree() {
  skillTreeEl.style.display = "block";
  lessonArea.style.display = "none";
  lessonsContainer.innerHTML = "";

  // Show initial 5 lessons
  for (let i = 1; i <= 5; i++) {
    const btn = document.createElement("button");
    btn.textContent = `Lesson ${i}`;
    btn.disabled = false;
    btn.onclick = () => startLesson(i);
    lessonsContainer.appendChild(btn);
  }

  // Load More button
  const loadMoreBtn = document.createElement("button");
  loadMoreBtn.textContent = "Load More Lessons";
  loadMoreBtn.onclick = () => {
    const currentCount = lessonsContainer.querySelectorAll("button").length - 1; // exclude Load More
    for (let i = currentCount + 1; i <= currentCount + 5; i++) {
      const btn = document.createElement("button");
      btn.textContent = `Lesson ${i}`;
      btn.disabled = false;
      btn.onclick = () => startLesson(i);
      lessonsContainer.insertBefore(btn, loadMoreBtn);
    }
  };
  lessonsContainer.appendChild(loadMoreBtn);
}

function startLesson(lessonNumber) {
  currentLessonNumber = lessonNumber;
  currentQuestionIndex = 0;
  timeLeft = lessonDuration;
  hearts = maxHearts;
  updateHeartsDisplay();
  skillTreeEl.style.display = "none";
  lessonArea.style.display = "block";
  startLessonTimer();
  showQuestion();
}

function startLessonTimer() {
  clearInterval(lessonTimer);
  updateTimerDisplay();
  lessonTimer = setInterval(() => {
    timeLeft--;
    updateTimerDisplay();
    if (timeLeft <= 0) {
      clearInterval(lessonTimer);
      // Use a custom message box instead of alert
      showMessageBox("⏰ Time's up! Lesson ended.");
      finishLesson();
    }
  }, 1000);
}

function updateTimerDisplay() {
  timerEl.textContent = `Time left: ${timeLeft}s`;
}

function updateHeartsDisplay() {
  heartsEl.textContent = `❤️ Hearts: ${"❤️".repeat(hearts)}${"🤍".repeat(maxHearts - hearts)}`;
}

function showQuestion() {
  const lesson = generateLesson(currentLanguage, currentLessonNumber);
  const q = lesson.questions[currentQuestionIndex];

  // Display the English prompt, but WITHOUT the phonetic pronunciation
  questionEl.innerHTML = `Translate "${q.promptEnglish}" into ${currentLanguage}:`;
  feedbackEl.textContent = "";
  optionsEl.innerHTML = "";
  textAnswerEl.classList.add("hidden");
  submitBtn.classList.add("hidden");
  textAnswerEl.value = "";

  // "I don't know" button
  const dontKnowBtn = document.createElement("button");
  dontKnowBtn.textContent = "I don't know ❓";
  dontKnowBtn.onclick = () => showCorrectAnswer(q.correctAnswer, q.correctAnswerPhonetic);
  optionsEl.appendChild(dontKnowBtn);

  if (q.type === "multiple") {
    q.options.forEach(opt => {
      const btn = document.createElement("button");
      let phoneticForOption = "";

      // Try to find phonetic in languageWords (for core words like hello, thank you, goodbye)
      const langData = languageWords[currentLanguage];
      if (langData) {
        for (const key in langData) {
          if (langData[key].word === opt) {
            phoneticForOption = ` (${langData[key].phonetic})`;
            break;
          }
        }
      }

      // If not found in languageWords, try to find it in wordBanks (for general wrong options)
      if (!phoneticForOption) {
        const wordBankForLang = wordBanks[currentLanguage];
        if (wordBankForLang) {
          const foundItem = wordBankForLang.find(item => item.word === opt);
          if (foundItem) {
            phoneticForOption = ` (${foundItem.phonetic})`;
          }
        }
      }

      btn.textContent = `${opt}${phoneticForOption}`; // Add phonetic to button text
      btn.onclick = () => checkAnswer(opt);
      optionsEl.appendChild(btn);
    });
  } else {
    textAnswerEl.classList.remove("hidden");
    submitBtn.classList.remove("hidden");
    submitBtn.onclick = () => checkAnswer(textAnswerEl.value.trim());
  }
}

function checkAnswer(ans) {
  const lesson = generateLesson(currentLanguage, currentLessonNumber);
  const q = lesson.questions[currentQuestionIndex];

  if (ans.toLowerCase() === q.correctAnswer.toLowerCase()) {
    feedbackEl.textContent = "✅ Correct!";
    xp += 10;
    streak += 1;
    updateStats();

    currentQuestionIndex++;
    if (currentQuestionIndex >= lesson.questions.length) {
      finishLesson();
    } else {
      showQuestion();
    }
  } else {
    hearts--;
    updateHeartsDisplay();
    feedbackEl.textContent = `❌ Incorrect! Hearts left: ${hearts}`;
    streak = 0;
    updateStats();
    if (hearts <= 0) {
      showMessageBox("💔 No hearts left! Lesson over.");
      finishLesson();
    }
  }
}

function showCorrectAnswer(correct, phonetic) {
  hearts--;
  updateHeartsDisplay();
  feedbackEl.textContent = `💡 The correct answer is: "${correct}" (${phonetic}). Hearts left: ${hearts}`;
  streak = 0;
  updateStats();
  if (hearts <= 0) {
    setTimeout(() => {
      showMessageBox("💔 No hearts left! Lesson over.");
      finishLesson();
    }, 1500);
  } else {
    setTimeout(() => {
      currentQuestionIndex++;
      const lesson = generateLesson(currentLanguage, currentLessonNumber);
      if (currentQuestionIndex >= lesson.questions.length) {
        finishLesson();
      } else {
        showQuestion();
      }
    }, 2000);
  }
}

function finishLesson() {
  clearInterval(lessonTimer);
  showSkillTree();
  showMessageBox(`🎉 You finished lesson ${currentLessonNumber} in ${currentLanguage}!`);
}

function backToSkillTree() {
  clearInterval(lessonTimer);
  lessonArea.style.display = "none";
  skillTreeEl.style.display = "block";
}

function goBackToLanguages() {
  clearInterval(lessonTimer);
  lessonTimer = null;
  timeLeft = lessonDuration;
  hearts = maxHearts;
  currentLanguage = null;
  currentLessonNumber = 1;
  currentQuestionIndex = 0;
  feedbackEl.textContent = "";
  textAnswerEl.value = "";
  optionsEl.innerHTML = "";
  lessonArea.style.display = "none";
  skillTreeEl.style.display = "none";
  languageSelectEl.style.display = "block";
}

function updateStats() {
  xpEl.textContent = xp;
  streakEl.textContent = streak;
  localStorage.setItem("xp", xp);
  localStorage.setItem("streak", streak);
}


// Custom message box function
function showMessageBox(message) {
  const messageBox = document.createElement('div');
  messageBox.id = 'message-box'; // Assign an ID for styling
  messageBox.innerHTML = `<p>${message}</p><button id="message-box-ok-btn" style="margin-top: 15px;">OK</button>`;
  document.body.appendChild(messageBox);

  document.getElementById('message-box-ok-btn').onclick = () => {
    document.body.removeChild(messageBox);
  };
}

// Mascot movement logic
function animateMascot() {
  const containerWidth = window.innerWidth;
  const mascotWidth = mascotEl.offsetWidth;

  // Update position
  mascotPosition += mascotDirection * mascotSpeed;

  // Reverse direction if hitting boundaries
  if (mascotDirection === 1 && mascotPosition + mascotWidth > containerWidth - 15) { // -15 for right padding
    mascotDirection = -1;
    mascotEl.style.transform = 'scaleX(-1)'; // Flip horizontally
  } else if (mascotDirection === -1 && mascotPosition < 15) { // 15 for left padding
    mascotDirection = 1;
    mascotEl.style.transform = 'scaleX(1)'; // Flip back
  }

  // Apply new position
  mascotEl.style.left = `${mascotPosition}px`;

  mascotAnimationId = requestAnimationFrame(animateMascot);
}

// Mascot interaction: speak a random message and flash sunglasses
let isMascotSpeaking = false;
function interactWithMascot() {
  if (isMascotSpeaking) return; // Prevent multiple speeches at once

  isMascotSpeaking = true;
  const randomMessage = triblazeMessages[Math.floor(Math.random() * triblazeMessages.length)];

  // Flash sunglasses effect
  mascotEl.classList.add('flash');
  setTimeout(() => {
    mascotEl.classList.remove('flash');
    isMascotSpeaking = false; // Allow speaking again after a short delay
  }, 1000); // Flash for 1 second
}


// Setup language buttons and navigation on DOM ready
document.addEventListener("DOMContentLoaded", () => {
  // Set initial mascot position
  mascotEl.style.left = '15px'; // Start from the left
  animateMascot(); // Start mascot animation

  // Add click listener to mascot
  mascotEl.addEventListener('click', interactWithMascot);

  // Initially show only the welcome screen
  welcomeScreenEl.style.display = 'flex';
  languageSelectEl.style.display = 'none';
  skillTreeEl.style.display = 'none';
  lessonArea.style.display = 'none';
  xpEl.parentElement.style.display = 'none'; // Hide stats initially

  startLearningBtn.addEventListener('click', () => {
    welcomeScreenEl.style.display = 'none';
    languageSelectEl.style.display = 'block';
    xpEl.parentElement.style.display = 'flex'; // Show stats after welcome
  });

  // Language buttons must have data-lang attribute
  document.querySelectorAll('#language-select button').forEach(btn => {
    btn.addEventListener('click', () => {
      const lang = btn.getAttribute("data-lang");
      if (lang) startLanguage(lang);
    });
  });

  document.getElementById('back-to-languages-1').addEventListener('click', goBackToLanguages);
  document.getElementById('back-to-languages-2').addEventListener('click', goBackToLanguages);
  document.getElementById('back-to-skill-tree').addEventListener('click', backToSkillTree);
});

// Adjust mascot position on window resize
window.addEventListener('resize', () => {
  cancelAnimationFrame(mascotAnimationId); // Stop current animation
  mascotPosition = 0; // Reset position
  mascotDirection = 1; // Reset direction
  mascotEl.style.transform = 'scaleX(1)'; // Reset flip
  mascotEl.style.left = '15px'; // Reset to start
  animateMascot(); // Restart animation
});